﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radPvr = New System.Windows.Forms.RadioButton()
        Me.radWinTV = New System.Windows.Forms.RadioButton()
        Me.lstView = New System.Windows.Forms.ListView()
        Me.ProgramName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.NextRunTime = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ProgramInfo = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Rec = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Duration = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lstBx = New System.Windows.Forms.ListBox()
        Me.btnRec = New System.Windows.Forms.Button()
        Me.btnRec01 = New System.Windows.Forms.Button()
        Me.btnRec02 = New System.Windows.Forms.Button()
        Me.btnRec03 = New System.Windows.Forms.Button()
        Me.btnRec04 = New System.Windows.Forms.Button()
        Me.btnRec05 = New System.Windows.Forms.Button()
        Me.btnRec06 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.OliveDrab
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(10, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(235, 76)
        Me.Label1.TabIndex = 0
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.OliveDrab
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Location = New System.Drawing.Point(56, 411)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(537, 37)
        Me.Label7.TabIndex = 6
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnAdd.Location = New System.Drawing.Point(131, 35)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(146, 35)
        Me.btnAdd.TabIndex = 7
        Me.btnAdd.Text = "ADD PROGRAM"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.OliveDrab
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(12, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(228, 36)
        Me.Label2.TabIndex = 8
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(549, 53)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(130, 35)
        Me.btnDelete.TabIndex = 9
        Me.btnDelete.Text = "DELELTE PROGRAM"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(549, 94)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(130, 35)
        Me.btnEdit.TabIndex = 10
        Me.btnEdit.Text = "EDIT PROGRAM"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radPvr)
        Me.GroupBox1.Controls.Add(Me.radWinTV)
        Me.GroupBox1.Controls.Add(Me.btnAdd)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Yellow
        Me.GroupBox1.Location = New System.Drawing.Point(260, 52)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(283, 76)
        Me.GroupBox1.TabIndex = 11
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "SOURCE SELECTION"
        '
        'radPvr
        '
        Me.radPvr.AutoSize = True
        Me.radPvr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPvr.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.radPvr.Location = New System.Drawing.Point(6, 46)
        Me.radPvr.Name = "radPvr"
        Me.radPvr.Size = New System.Drawing.Size(83, 20)
        Me.radPvr.TabIndex = 13
        Me.radPvr.TabStop = True
        Me.radPvr.Text = "HD PVR"
        Me.radPvr.UseVisualStyleBackColor = True
        '
        'radWinTV
        '
        Me.radWinTV.AutoSize = True
        Me.radWinTV.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radWinTV.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.radWinTV.Location = New System.Drawing.Point(6, 25)
        Me.radWinTV.Name = "radWinTV"
        Me.radWinTV.Size = New System.Drawing.Size(79, 20)
        Me.radWinTV.TabIndex = 12
        Me.radWinTV.TabStop = True
        Me.radWinTV.Text = "WIN TV"
        Me.radWinTV.UseVisualStyleBackColor = True
        '
        'lstView
        '
        Me.lstView.BackColor = System.Drawing.Color.DimGray
        Me.lstView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ProgramName, Me.NextRunTime, Me.ProgramInfo, Me.Rec, Me.Duration})
        Me.lstView.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstView.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lstView.Location = New System.Drawing.Point(15, 156)
        Me.lstView.Name = "lstView"
        Me.lstView.Size = New System.Drawing.Size(685, 53)
        Me.lstView.TabIndex = 12
        Me.lstView.UseCompatibleStateImageBehavior = False
        Me.lstView.View = System.Windows.Forms.View.Details
        '
        'ProgramName
        '
        Me.ProgramName.Text = "Program Name"
        Me.ProgramName.Width = 220
        '
        'NextRunTime
        '
        Me.NextRunTime.Text = "Next Run Time"
        Me.NextRunTime.Width = 160
        '
        'ProgramInfo
        '
        Me.ProgramInfo.Text = "Program Info"
        Me.ProgramInfo.Width = 120
        '
        'Rec
        '
        Me.Rec.Text = "Rec"
        '
        'Duration
        '
        Me.Duration.Text = "Duration"
        Me.Duration.Width = 85
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(199, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(263, 35)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Win Tv Scheduler"
        '
        'lstBx
        '
        Me.lstBx.BackColor = System.Drawing.Color.Gray
        Me.lstBx.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstBx.FormattingEnabled = True
        Me.lstBx.ItemHeight = 25
        Me.lstBx.Location = New System.Drawing.Point(17, 183)
        Me.lstBx.Name = "lstBx"
        Me.lstBx.Size = New System.Drawing.Size(683, 179)
        Me.lstBx.TabIndex = 14
        '
        'btnRec
        '
        Me.btnRec.BackgroundImage = CType(resources.GetObject("btnRec.BackgroundImage"), System.Drawing.Image)
        Me.btnRec.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnRec.Location = New System.Drawing.Point(531, 191)
        Me.btnRec.Name = "btnRec"
        Me.btnRec.Size = New System.Drawing.Size(30, 18)
        Me.btnRec.TabIndex = 15
        Me.btnRec.UseVisualStyleBackColor = True
        Me.btnRec.Visible = False
        '
        'btnRec01
        '
        Me.btnRec01.BackgroundImage = CType(resources.GetObject("btnRec01.BackgroundImage"), System.Drawing.Image)
        Me.btnRec01.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnRec01.Location = New System.Drawing.Point(531, 215)
        Me.btnRec01.Name = "btnRec01"
        Me.btnRec01.Size = New System.Drawing.Size(30, 18)
        Me.btnRec01.TabIndex = 16
        Me.btnRec01.UseVisualStyleBackColor = True
        Me.btnRec01.Visible = False
        '
        'btnRec02
        '
        Me.btnRec02.BackgroundImage = CType(resources.GetObject("btnRec02.BackgroundImage"), System.Drawing.Image)
        Me.btnRec02.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnRec02.Location = New System.Drawing.Point(531, 239)
        Me.btnRec02.Name = "btnRec02"
        Me.btnRec02.Size = New System.Drawing.Size(30, 18)
        Me.btnRec02.TabIndex = 17
        Me.btnRec02.UseVisualStyleBackColor = True
        Me.btnRec02.Visible = False
        '
        'btnRec03
        '
        Me.btnRec03.BackgroundImage = CType(resources.GetObject("btnRec03.BackgroundImage"), System.Drawing.Image)
        Me.btnRec03.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnRec03.Location = New System.Drawing.Point(531, 263)
        Me.btnRec03.Name = "btnRec03"
        Me.btnRec03.Size = New System.Drawing.Size(30, 18)
        Me.btnRec03.TabIndex = 18
        Me.btnRec03.UseVisualStyleBackColor = True
        Me.btnRec03.Visible = False
        '
        'btnRec04
        '
        Me.btnRec04.BackgroundImage = CType(resources.GetObject("btnRec04.BackgroundImage"), System.Drawing.Image)
        Me.btnRec04.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnRec04.Location = New System.Drawing.Point(531, 287)
        Me.btnRec04.Name = "btnRec04"
        Me.btnRec04.Size = New System.Drawing.Size(30, 18)
        Me.btnRec04.TabIndex = 19
        Me.btnRec04.UseVisualStyleBackColor = True
        Me.btnRec04.Visible = False
        '
        'btnRec05
        '
        Me.btnRec05.BackgroundImage = CType(resources.GetObject("btnRec05.BackgroundImage"), System.Drawing.Image)
        Me.btnRec05.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnRec05.Location = New System.Drawing.Point(531, 311)
        Me.btnRec05.Name = "btnRec05"
        Me.btnRec05.Size = New System.Drawing.Size(30, 18)
        Me.btnRec05.TabIndex = 20
        Me.btnRec05.UseVisualStyleBackColor = True
        Me.btnRec05.Visible = False
        '
        'btnRec06
        '
        Me.btnRec06.BackgroundImage = CType(resources.GetObject("btnRec06.BackgroundImage"), System.Drawing.Image)
        Me.btnRec06.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnRec06.Location = New System.Drawing.Point(531, 335)
        Me.btnRec06.Name = "btnRec06"
        Me.btnRec06.Size = New System.Drawing.Size(30, 18)
        Me.btnRec06.TabIndex = 21
        Me.btnRec06.UseVisualStyleBackColor = True
        Me.btnRec06.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gray
        Me.ClientSize = New System.Drawing.Size(712, 462)
        Me.Controls.Add(Me.btnRec06)
        Me.Controls.Add(Me.btnRec05)
        Me.Controls.Add(Me.btnRec04)
        Me.Controls.Add(Me.btnRec03)
        Me.Controls.Add(Me.btnRec02)
        Me.Controls.Add(Me.btnRec01)
        Me.Controls.Add(Me.btnRec)
        Me.Controls.Add(Me.lstBx)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lstView)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Main DVR"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnEdit As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radPvr As RadioButton
    Friend WithEvents radWinTV As RadioButton
    Friend WithEvents lstView As ListView
    Friend WithEvents ProgramName As ColumnHeader
    Friend WithEvents NextRunTime As ColumnHeader
    Friend WithEvents ProgramInfo As ColumnHeader
    Friend WithEvents Rec As ColumnHeader
    Friend WithEvents Duration As ColumnHeader
    Friend WithEvents Label3 As Label
    Friend WithEvents lstBx As ListBox
    Friend WithEvents btnRec As Button
    Friend WithEvents btnRec01 As Button
    Friend WithEvents btnRec02 As Button
    Friend WithEvents btnRec03 As Button
    Friend WithEvents btnRec04 As Button
    Friend WithEvents btnRec05 As Button
    Friend WithEvents btnRec06 As Button
End Class
