﻿Public Class Form1


    Public dvrName(2) As String


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAdd.Click


        If radWinTV.Checked = True Then
            dvrName(0) = radWinTV.Text
            dvrName(2) = dvrName(0)
            'show the add program form
            Dim addPrgm As New AddPrgmFrm
            addPrgm.Label3.Text = "Add Program"
            addPrgm.Text = "Add Program"
            addPrgm.lblSaveToOutput.Text = dvrName(2)
            addPrgm.lblPrgmName.Text = "Program Name:    " & dvrName(2)
            addPrgm.Show()
        ElseIf radPvr.Checked = True Then
            dvrName(1) = radPvr.Text
            dvrName(2) = dvrName(1)
            'show the add program form
            Dim addPrgm As New AddPrgmFrm
            addPrgm.Label3.Text = "Add Program"
            addPrgm.Text = "Add Program"
            addPrgm.lblSaveToOutput.Text = dvrName(2)
            addPrgm.lblPrgmName.Text = "Program Name:   " & dvrName(2)
            addPrgm.Show()
        ElseIf radPvr.Checked = False Or radWinTV.Checked = False Then
            MsgBox("PLEASE SELECT A DVR NAME", MsgBoxStyle.OkCancel)
        End If





    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

        If lstBx.SelectedIndex = -1 Then
            MsgBox("PLEASE SELECT A DVR NAME YOU WANT TO DELETE", MsgBoxStyle.OkCancel)
        Else
            'shows delete program form
            Dim DelPrgm As New DelPrgmFrm
            Dim addPrgm As New AddPrgmFrm
            DelPrgm.Text = "Delete Program"
            DelPrgm.Label3.Text = "Delete Program"
            addPrgm.recButtonVisibleSub()
            DelPrgm.ShowDialog()
        End If
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        'show delete program form
        If lstBx.SelectedIndex = -1 Then
            MsgBox("PLEASE SELECT A DVR NAME YOU WANT TO EDIT", MsgBoxStyle.OkCancel)
        Else
            Dim addPrgm As New AddPrgmFrm
            addPrgm.Label3.Text = "Edit Program"
            addPrgm.Text = "Edit Program"
            addPrgm.lblSaveToOutput.Text = dvrName(2)
            addPrgm.lblPrgmName.Text = "Program Name:  " & dvrName(2)
            lstBx.Items.Remove(lstBx.SelectedItem)
            addPrgm.recButtonVisibleSub()
            addPrgm.ShowDialog()

        End If
    End Sub

End Class
