﻿Public Class DelPrgmFrm
    Private Sub btnYes_Click(sender As Object, e As EventArgs) Handles btnYes.Click
        Form1.lstBx.Items.Remove(Form1.lstBx.SelectedItem)
        recButtonVisibleSub2()
        Me.Close()


    End Sub

    Private Sub btnNo_Click(sender As Object, e As EventArgs) Handles btnNo.Click
        Me.Close()
    End Sub



    Public Sub recButtonVisibleSub2()




        Select Case Form1.lstBx.Items.Count

            Case = 1
                Form1.btnRec.Visible = True
                Form1.btnRec01.Visible = False
                Form1.btnRec02.Visible = False
                Form1.btnRec03.Visible = False
                Form1.btnRec04.Visible = False
                Form1.btnRec05.Visible = False
                Form1.btnRec06.Visible = False
            Case = 2
                Form1.btnRec.Visible = True
                Form1.btnRec01.Visible = True
                Form1.btnRec02.Visible = False
                Form1.btnRec03.Visible = False
                Form1.btnRec04.Visible = False
                Form1.btnRec05.Visible = False
                Form1.btnRec06.Visible = False
            Case = 3
                Form1.btnRec.Visible = True
                Form1.btnRec01.Visible = True
                Form1.btnRec02.Visible = True
                Form1.btnRec03.Visible = False
                Form1.btnRec04.Visible = False
                Form1.btnRec05.Visible = False
                Form1.btnRec06.Visible = False
            Case = 4
                Form1.btnRec.Visible = True
                Form1.btnRec01.Visible = True
                Form1.btnRec02.Visible = True
                Form1.btnRec03.Visible = True
                Form1.btnRec04.Visible = False
                Form1.btnRec05.Visible = False
                Form1.btnRec06.Visible = False
            Case = 5
                Form1.btnRec.Visible = True
                Form1.btnRec01.Visible = True
                Form1.btnRec02.Visible = True
                Form1.btnRec03.Visible = True
                Form1.btnRec04.Visible = True
                Form1.btnRec05.Visible = False
                Form1.btnRec06.Visible = False
            Case = 5
                Form1.btnRec.Visible = True
                Form1.btnRec01.Visible = True
                Form1.btnRec02.Visible = True
                Form1.btnRec03.Visible = True
                Form1.btnRec04.Visible = True
                Form1.btnRec05.Visible = True
                Form1.btnRec06.Visible = False
            Case Else
                Form1.btnRec.Visible = False
                Form1.btnRec01.Visible = False
                Form1.btnRec02.Visible = False
                Form1.btnRec03.Visible = False
                Form1.btnRec04.Visible = False
                Form1.btnRec05.Visible = False
                Form1.btnRec06.Visible = False


        End Select
    End Sub
End Class