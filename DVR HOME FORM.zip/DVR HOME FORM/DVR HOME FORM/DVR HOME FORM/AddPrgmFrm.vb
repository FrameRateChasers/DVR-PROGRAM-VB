﻿Public Class AddPrgmFrm

    Const Sub_Script As Double = 3
    Const IntHold_Sub_Script As Double = 5
    Dim TimeShit(Sub_Script) As Double
    Dim TimeShit3 As Integer
    Dim intHold(IntHold_Sub_Script) As Double
    Dim intOnehr As Integer = 60
    Dim intHalfhr As Integer = 30

    Dim d1 As New DateTime
    Dim d2 As New DateTime
    Dim chnlNum As Integer
    Dim x As Double
    Dim y As Double
    Dim z As Double
    Dim q As Double




    Private Sub btnSet_Click(sender As Object, e As EventArgs) Handles btnSet.Click

        If Not Integer.TryParse(txtChannel.Text, chnlNum) Then
            MsgBox("PLEASE ENTER A NUMERIC DIGIT BETWEEN 2 to 1600 ", MsgBoxStyle.OkCancel)
        Else
            ChannelNumSub()

            TimeShit(0) = numericHr.Value
            TimeShit(1) = numericMin.Value
            TimeShit(2) = numericMinDuration.Value
            TimeShit3 = numericMinDuration.Value
            intHold(0) = 0.5
            d1 = DateTimePicker1.Value
            d2 = DateTimePicker2.Value
            TimeShitSub()

            Dim duration As New TimeSpan(0, TimeShit(0), TimeShit(1), 0)
            Dim duration2 As New TimeSpan(0, z, q, 0)
            Dim output As String = duration.ToString("g")
            Dim output2 As String = duration2.ToString("g")


            lblTimeToEndOutput.Text = intHold(2) & ":" & intHold(4)
            Form1.lstBx.Items.Add(Form1.dvrName(2) & "                        " & d1 & "               " & "ch." & chnlNum & "                      " & output2)
            Form1.Label2.Text = d1.ToString("D")
            recButtonVisibleSub()


            Form1.Label1.Text = output
            Form1.Label7.Text = "New Program " & Form1.dvrName(2) & "    has been added"
        End If
    End Sub









    Public Sub ChannelNumSub()
        Integer.TryParse(txtChannel.Text, chnlNum)
        Select Case chnlNum
            Case 2 To 100
                lblMessage.Text = "BROADCAST"
            Case 101 To 1600
                lblMessage.Text = "DIGITAL"
            Case Else
                lblMessage.Text = "INVALID CHANNEL"
        End Select
    End Sub


    Public Sub recButtonVisibleSub()




        Select Case Form1.lstBx.Items.Count
            Case = 1
                Form1.btnRec.Visible = True
            Case = 2
                Form1.btnRec01.Visible = True
            Case = 3
                Form1.btnRec02.Visible = True
            Case = 4
                Form1.btnRec03.Visible = True
            Case = 5
                Form1.btnRec04.Visible = True
            Case = 6
                Form1.btnRec05.Visible = True
            Case = 7
                Form1.btnRec06.Visible = True
            Case Else
                If Form1.lstBx.Items.Count > 7 Then
                    MsgBox("you can add up to 8 dvr names")
                    Form1.lstBx.Items.Clear()
                    Form1.btnRec.Visible = False
                    Form1.btnRec01.Visible = False
                    Form1.btnRec02.Visible = False
                    Form1.btnRec03.Visible = False
                    Form1.btnRec04.Visible = False
                    Form1.btnRec05.Visible = False
                    Form1.btnRec06.Visible = False
                End If

        End Select


    End Sub

    Public Sub TimeShitSub()
        Select Case TimeShit(2)
            Case 30, 90, 150, 210, 270, 330, 390, 450, 510, 570, 630, 690
                intHold(1) = TimeShit(2) / intOnehr 'stored value 1 =  duration / 60
                intHold(1) -= intHold(0) ' stored value 1 - 0.5
                intHold(2) = intHold(1) + TimeShit(0) 'stored value 2 = stored value 1 + hour
                intHold(3) = TimeShit(1) + intHalfhr ' stored value 3 = min + 30
                x = TimeShit(2) / 60
                y = x - 0.2

                z = y - 0.3
                q = 30

                If intHold(3) > 59 Then
                    intHold(4) = intHold(3) - 60
                    intHold(2) = intHold(2) + 1
                Else
                    intHold(4) = intHold(3)
                End If
            Case 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720
                intHold(5) = TimeShit(2) / intOnehr
                intHold(2) = TimeShit(0) + intHold(5)
                intHold(4) = TimeShit(1)

                x = TimeShit(2) / 60

                z = x
                q = 0

            Case Else
                MsgBox("PLEASE ENTER DURATION IN HALF HOUR INTERVALS ", MsgBoxStyle.OkCancel)
                Form1.lstBx.Items.RemoveAt(Form1.lstBx.Items.Count - 1)

        End Select
    End Sub

    Private Sub btnCncl_Click(sender As Object, e As EventArgs) Handles btnCncl.Click
        Me.Close()
    End Sub

    Private Sub RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton6.CheckedChanged

    End Sub
End Class